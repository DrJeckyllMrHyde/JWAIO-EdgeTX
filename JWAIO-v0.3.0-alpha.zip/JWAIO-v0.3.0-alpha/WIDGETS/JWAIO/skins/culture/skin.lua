-- ============================================================================
-- JWAIO - Jeckyll Widget All in One
-- Copyright 2026 DrJeckyllMrHyde
-- SPDX-License-Identifier: Apache-2.0
-- Fichier : skins/culture/skin.lua
-- Version : 0.3.0
-- Role    : identite, fichiers et palette du skin prive CultureFPV.
-- Prive   : essais locaux uniquement, aucune publication GitHub autorisee.
-- ============================================================================

return {
  api = 1,
  id = "culturefpv",
  name = "CultureFPV",
  slot = 2,
  background = "background.png",
  logo = "logo.png",
  panelsBaked = true,
  private = true,
  palette = {
    black = {0, 0, 0},
    panel = {0, 0, 0},
    line = {0, 184, 210},
    white = {248, 250, 252},
    grey = {155, 177, 188},
    orange = {0, 184, 210},
    green = {0, 184, 210},
    red = {237, 28, 36},
    blue = {0, 184, 210}
  }
}

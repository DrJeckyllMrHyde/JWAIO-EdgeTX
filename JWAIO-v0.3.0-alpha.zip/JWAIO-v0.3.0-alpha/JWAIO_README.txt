JWAIO - JECKYLL WIDGET ALL IN ONE - V0.3.0
Iteration locale : alpha-2 (correction du clignotement NO_DATA).
Consulter MODE_EMPLOI.txt / ALPHA_TESTS_0.3.txt dans le ZIP pour les tests.

VERSION LOCALE DE TEST - NE PAS PUBLIER

Installation : extraire ce ZIP a la racine de la memoire de stockage EdgeTX
(memoire interne, ou carte microSD lorsqu'elle est utilisee par la radio).

Puis :
1. Redemarrer EdgeTX.
2. Garder l'instance 0.3 existante. Depuis 0.2.1 seulement, la recreer en plein ecran.
3. Ouvrir ses reglages et selectionner le skin, les sources et les switches.

Points de controle V0.3.0 :
- Skin est maintenant la premiere ligne du menu.
- JWAIO et CultureFPV peuvent etre selectionnes sans remplacer les fichiers.
- Le fond JWAIO est un PNG RGB opaque et continu, sans couche alpha.
- Si un skin est absent ou invalide, le widget revient automatiquement a JWAIO.
- LQ a ete retire du menu : le capteur RQly est lu directement par le script.
- Fly Time reprend le TIMER 1 de la radio.
- Fly Total reprend le TIMER 2 de la radio.
- BatType permet de choisir LiPo, LiIon ou LiHv.
- LinkType permet de choisir ELRS ou TBS_CF.
- Cells est configure a 6S par defaut.
- Decouvrir RxBt, RQly, GPS, Alt, GSpd et Sats avant d'ajouter le widget.
- GPS : 1-4 satellites rouge, 5-7 orange, 8 et plus vert.
- GPS, GSpd et Sats sont lus toutes les secondes ; Alt et RSSI a chaque tick.
- Relacher ARM remet Fly Time/TIMER 1 a zero, sans toucher TIMER 2.
- Deux armements dans la meme seconde creent deux journaux distincts.
- Les annonces modes, switches, batterie pleine, satellite et altitude sont actives.
- L'alerte altitude utilise Alt > 120 m, une fois par armement.
- Batterie : une annonce par episode et recuperation stable de 5 s pour rearmement.
- L'alerte throttle se declenche apres 3 secondes a 95 % ou plus.
- Qwad Finder s'active avec Beeper, Flip ou RTH.
- Le bip de recherche accelere lorsque le RSSI recu devient plus fort.
- Finder prioritaire sur les voix JWAIO ; cadence cible proche de 0,20 s.
- Le finder est libere lorsque Beeper, Flip et RTH sont tous desactives.
- Speed/Dist sont affiches a gauche et Alt/Total a droite, sans cadre.
- Le calcul de distance commence seulement avec ARM et throttle superieur a 5 %.
- Un controle moteur a 5 % ou moins conserve le resultat du dernier vrai vol.

Chemins principaux :
/WIDGETS/JWAIO/
/WIDGETS/JWAIO/skins/jwaio/
/WIDGETS/JWAIO/skins/culture/ (test prive uniquement)
/SOUNDS/fr/JWAIO/
/LOGS/JWAIO/

Fichiers GPS :
/LOGS/JWAIO/FYYMMDD_HHMMSS.csv
/LOGS/JWAIO/EYYMMDD_HHMMSS.csv (evenements de diagnostic, alpha locale)
/LOGS/JWAIO/lastpos.txt
/LOGS/JWAIO/lastdistance.txt

Cette version contient des sons WAV de test. Consulter la documentation du projet
avant de tester les alertes avec les helices montees.

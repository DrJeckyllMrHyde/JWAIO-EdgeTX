# JWAIO_BOXER_V0.2.1_Alpha

Script pour RadioMaster Boxer, écran monochrome 128 × 64, EdgeTX 2.12.2. Interface freestyle sans GPS, à ouvrir depuis SYS → TOOLS → JWAIO Boxer.

## Installation

1. Sauvegardez la carte SD et vos réglages avant la copie.
2. Copiez les dossiers SCRIPTS, SOUNDS et LOGS de cette archive à la racine de la carte SD, en fusionnant les dossiers et en remplaçant les fichiers du script. Copiez aussi les seize sons.
3. Conservez le contenu existant de SCRIPTS/JWBOX/CFG : il contient les réglages et compteurs par modèle. Cette livraison conserve les mêmes chemins et le même format de sauvegarde.
4. Si un ancien SCRIPTS/TOOLS/jwbox.luac est présent, retirez uniquement ce fichier compilé ; conservez jwbox.lua et les autres fichiers de votre carte.
5. Éjectez proprement le lecteur USB, débranchez le câble et redémarrez la radio avant les essais. Lors des tests utilisateur, le branchement USB a été associé à des silences et des gels ; les derniers essais sans USB se sont déroulés sans gel avec tous les sons audibles.
6. Ouvrez SYS → TOOLS → JWAIO Boxer et vérifiez les affectations dans les réglages, sur table, hélices retirées. Gardez l'outil ouvert : aucun suivi ne continue après sa fermeture.

Le nom de la livraison est JWAIO_BOXER_V0.2.1_Alpha. Le fichier de lancement reste jwbox.lua et les dossiers restent JWBOX pour conserver les réglages existants. Aucun mixage ni modèle EdgeTX n'est remplacé par cette archive.

## Modèle possédant déjà des annonces sonores

Vérifiez les annonces configurées dans les fonctions spéciales du modèle et les fonctions globales : une même commande peut déclencher une annonce EdgeTX et une annonce JWAIO, ce qui peut doubler ou retarder les messages. Pour isoler un conflit, notez vos réglages et désactivez temporairement seulement les annonces personnalisées qui font doublon. Conservez les alertes de sécurité de la radio.

Un risque de plantage avec un modèle possédant déjà des sons a également été signalé par l'utilisateur. Ce lien reste à confirmer par un essai comparatif ; il ne s'agit pas d'une cause démontrée.

## Réglages

Maintenir **SF bas cinq secondes**. Molette : sélectionner/modifier ; ENT : éditer/valider ; **SAUVER + QUITTER** : enregistrer et appliquer. RTN termine l'édition puis annule le brouillon. Hors menu, RTN sauvegarde et ferme l'outil.

| Réglage | Choix |
|---|---|
| Cellules | 1 à 8S |
| Batterie | LiPo / LiIon / LiHv |
| Capteur BAT | RxBt par défaut ; VFAS, Cels, Bat et capteurs du modèle |
| Critique V/C | 2,80 à 4,35 V, pas de 0,01 V |
| Prearm | OFF ou SA à SF, position physique |
| Arm | SA à SF, position physique |
| Angle | OFF ou SA à SD, position physique |
| BlackBox | OFF ou SA à SD, position physique |
| Beeper | OFF ou SA à SD, position physique |
| Flip | OFF ou SA à SD, position physique |
| Failsafe | OFF ou SA à SD, position physique |
| RTH | OFF ou SA à SD, position physique |
| Voie Gaz | CH1 à CH4 ; CH3 par défaut |
| Son | ON / OFF ; ENT long pour le test d'écoute |
| Journal SD | ON / OFF |

SA/SD/SE/SF : haut ou bas ; SB/SC : haut, milieu ou bas. Les flèches sont natives EdgeTX. Installation neuve : Arm SA bas, fonctions facultatives OFF ; anciennes affectations conservées. SF conserve aussi le raccourci fixe des réglages.

Le script lit des commandes radio, sans modifier les mixages ni commander le contrôleur de vol. BlackBox indique la commande d'enregistrement du quad ; Journal SD concerne les CSV de JWAIO. ARM, Angle, BlackBox, Failsafe et RTH ne sont pas des confirmations du contrôleur de vol.

## Écrans

- **Accueil** : logo pixel art, texte centré, Accueil.wav une fois à l'ouverture après 0,30 s, puis une fois par retour après débranchement présumé. Visiter les réglages ne rejoue pas l'intro.
- **Avant vol** : état du script, état du capteur, jauge indicative, tension par cellule et ELRS. Un défaut du seul capteur BAT reste affiché ; les valeurs périmées ne sont pas réutilisées. JWAIO OK signifie chargement réussi, pas validation matérielle du quad.
- **En vol** : nouveau chrono dès ARM avec batterie valide, même gaz à zéro. [ARM] seulement lorsque la commande est active, Acro/Angle toujours indiqués. Les compteurs continuent même si une autre page est affichée.
- **Bilan** : désarmement après un vol strictement supérieur à dix secondes. Reste affiché jusqu'au débranchement, au réarmement ou à une commande Finder. Réarmer lance un nouveau chrono ; quitter Finder restaure le bilan inchangé.
- **Finder** : Beeper OU Flip OU RTH sélectionne cette page. Annonce de commande une fois, puis bips selon RSSI filtré ou LQ de repli. Sans mesure : pas de bip. Le Finder ne donne ni distance ni direction.
- **Batterie critique** : tension strictement sous le seuil ; récupération à seuil +0,08 V pendant deux secondes. En vol, cet écran reste prioritaire sur Finder ; après désarmement, le bilan reste conservé.
- **Télémétrie absente** : perte de liaison pendant un vol armé d'au moins dix secondes, mémorisée après désarmement jusqu'au retour de la liaison. C'est une suspicion de crash.

Priorités : réglages, perte qualifiée, critique en vol, accueil sans batterie présumée, Finder, vol, bilan, avant vol.

## Sons et test d'écoute

Tous les sons utilisent `SOUNDS/fr/JWBOX` : PCM mono 16 bits 32 kHz. Le script respecte le volume WAV de la radio et le réglage Son. Il ne force pas un volume maximal et ne remplace pas les alarmes du firmware.

L'intro initiale précède les confirmations. Les sons déjà demandés disposent d'une réserve correspondant à la durée réelle du WAV. Beeper/Flip/RTH sont annoncés une fois avant les bips Finder ; Failsafe peut également être annoncé pendant Finder. Les autres annonces attendent sa désactivation si elles sont encore pertinentes. Une impulsion Prearm attend au maximum six secondes.

Batterie pleine, après trois secondes stables en Avant vol : LiPo/LiIon 4,20 ±0,20 V ; LiHv 4,35 ±0,20 V. Une annonce par session batterie, pas à chaque désarmement. ELRS : une annonce à 70 % ou moins uniquement armé ; seule une mesure valide supérieure à 70 % réarme l'alerte.

### Test sur la ligne Son

1. Sur table, hélices retirées : couper ARM, Beeper, Flip et RTH.
2. Sauvegarder **Son ON**, puis revenir dans les réglages.
3. Sélectionner la ligne **Son**, sans l'éditer, et maintenir **ENT** pour lancer le test.
4. Écouter **Accueil → Prearm → Arm → Beeper → Flip → Failsafe → RTH**. Les annonces normales peuvent reprendre ensuite. Changer d'écran ne constitue pas une confirmation que les sons ont été entendus.

Le test est refusé si ARM/Finder est actif ou si Son est OFF. L'activation d'ARM/Finder pendant le test annule la suite après le WAV déjà demandé.

**SON ABSENT nom.wav** : vérifier ce fichier exact dans `SOUNDS/fr/JWBOX` sur la SD ; recopier tout le dossier SOUNDS. Le test relance le contrôle des fichiers. **SON ERREUR nom** : l'appel de lecture a levé une erreur.

Si les fichiers sont reconnus mais que seules certaines annonces restent muettes, relever les noms entendus et les noms manquants pendant ce test. playFile n'a aucun retour attestant que le haut-parleur a réellement produit le son : les tests sur ordinateur ne prouvent donc pas l'audibilité sur la radio.

## Batterie, débranchement et données

RxBt/VFAS/Bat doivent fournir la tension du pack ; la division par le nombre manuel de cellules donne une moyenne. Cels, s'il fournit une liste, utilise la cellule la plus faible. La jauge est indicative.

La radio ne détecte pas physiquement le retrait d'une LiPo. Une tension BAT valide égale à zéro est traitée comme un retrait ; une perte complète de télémétrie pendant une seconde, hors perte qualifiée, est assimilée à un débranchement. Une panne du seul capteur conserve le diagnostic. Une coupure RF au sol peut donc produire le même accueil ; en USB, une tension non nulle persistante empêche de déduire le retrait de la LiPo.

Les réglages et compteurs sont enregistrés par modèle dans deux copies vérifiées de `SCRIPTS/JWBOX/CFG`. Un vol actif est sauvegardé toutes les quinze secondes et à la sortie normale. Le journal CSV sans GPS utilise `LOGS/JWBOX`, un fichier par vol et quatorze colonnes. Les commandes BlackBox/Failsafe/RTH sont distinctes du journal.

## États et dépannage

| Affichage ou situation | Vérification à effectuer |
|---|---|
| Accueil sans LiPo | Brancher la batterie et attendre la télémétrie. Une absence de liaison ne prouve pas à elle seule le retrait de la batterie. |
| Défaut BAT en Avant vol ou Bilan | Vérifier le capteur choisi, sa présence dans la télémétrie et le nombre de cellules ; le défaut reste affiché pour permettre le contrôle. |
| Batterie critique | Vérifier la tension réelle et le seuil configuré pour le type de batterie. |
| Télémétrie absente après un vol | Vérifier la liaison et l'état du quad ; l'écran indique une perte qualifiée, pas une confirmation de crash. |
| Finder silencieux sans mesure | Aucune indication sonore de recherche n'est produite sans mesure exploitable. |
| SON ABSENT / SON ERREUR | Vérifier les seize WAV dans SOUNDS/fr/JWBOX, Son ON et le volume WAV de la radio ; tester sans USB. |
| Erreur SD ou sauvegarde refusée | Vérifier l'accès en écriture à la SD, les dossiers CFG et LOGS/JWBOX ; ne pas effacer les réglages pour résoudre un problème audio. |
| Erreur mémoire ou installation | Vérifier la copie des six Lua de la même livraison et retirer l'ancien jwbox.luac éventuel. Relever le message exact si l'erreur persiste. |

## Vérifications et statut Alpha

Les contrôles sur ordinateur couvrent la syntaxe Lua 5.3, les menus, les transitions d'écran, les sauvegardes simulées, le séquencement audio et les contraintes d'API monochrome simulées. Ils ne reproduisent pas le matériel ni le lecteur audio natif.

Le 31 octobre 2026, l'utilisateur confirme tous les sons audibles et l'absence de gel sur la dernière livraison testée sans USB. Cette finalisation conserve son fonctionnement et change le nom de livraison et la documentation. L'ensemble des fonctions en vol n'est pas déclaré validé.

Avant utilisation, contrôler le capteur batterie, les cellules, le seuil critique, les commandes d'armement et de modes, puis la sauvegarde et la relecture des réglages. Vérifier sur table le retour du Finder vers le bilan, le nouveau chrono au réarmement et le retour à l'accueil après débranchement. Les essais en vol restent distincts de ces contrôles.

Le code Lua est commenté et modifiable. Les tests, archives historiques et documents de développement restent dans le projet local ; ils ne sont pas nécessaires sur la SD. Les licences et attributions de cette livraison sont dans LICENSE, NOTICE et THIRD_PARTY_NOTICES.txt.

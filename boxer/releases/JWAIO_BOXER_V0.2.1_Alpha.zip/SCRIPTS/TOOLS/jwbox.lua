-- toolName = "TNS|JWAIO Boxer|TNE"
-- ============================================================================
-- JWAIO BOXER V0.2.1 Alpha TOOLS - interface EQUILIBRE, freestyle sans GPS
-- Copyright 2026 DrJeckyllMrHyde - SPDX-License-Identifier: Apache-2.0
-- Cible : RadioMaster Boxer / EdgeTX 2.12.2 / Lua 5.3.
--
-- INSTALLATION : copier SCRIPTS, SOUNDS et LOGS a la racine de la carte SD,
-- puis ouvrir SYS > TOOLS > JWAIO Boxer (dossier exact : /SCRIPTS/TOOLS/).
-- Garder l'outil ouvert pendant l'utilisation : aucun suivi apres fermeture.
--
-- COMMANDES PAR DEFAUT (modifiables dans les reglages, sauf maintien SF) :
-- SA bas : commande ARM par defaut ; haut : avant-vol ou bilan.
-- Beeper OU Flip OU RTH : ecran Finder. SF bas 5 s : reglages.
-- Seuil critique : strictement moins de 3.50 V par cellule, configurable.
-- Les interrupteurs lus ici ne changent JAMAIS les mixages du modele.
--
-- ORGANISATION POUR MODIFIER LE PROJET :
-- settings.lua : valeurs par defaut, menu, lecture/ecriture des sauvegardes.
-- core.lua     : capteurs, chronos, armement, priorite des ecrans.
-- ui.lua       : dessin de chaque ecran dans les 128 x 64 pixels.
-- audio.lua    : WAV JWAIO et exclusivite sonore du Finder.
-- logger.lua   : journaux CSV propres a cette version Boxer.
-- Les modules resident dans /SCRIPTS/JWBOX/, distinct du widget TX15.
-- ============================================================================
local BASE="/SCRIPTS/JWBOX/"
local settings,core,ui,audio,logger,c,store,s,voice,log
local menu=nil
local fatal=nil
local lastTick=nil
local saveError=nil
local saveDetail=nil
local nextCheckpoint=0
local initStage="INIT"

local function loadModule(name)
 -- Les fonctions temporaires du module precedent ne doivent pas rester
 -- en memoire pendant la compilation du suivant. Uniquement au chargement.
 initStage=name
 collectgarbage("collect")
 local chunk,err=loadScript(BASE..name..".lua","tx")
 if not chunk then error(err or ("Module absent: "..name)) end
 local result=chunk();chunk=nil
 collectgarbage("collect")
 return result
end
local function save(values)
 -- Recuperer les anciens tampons avant de creer le texte de sauvegarde.
 -- Appel ponctuel (menu/sortie/checkpoint), jamais a chaque image.
 collectgarbage("collect")
 -- Une carte absente/protegee ne doit pas interrompre l'ecran de vol.
 local ok,result,message,detail=pcall(settings.save,store,values)
 if not ok or not result then
  saveError=ok and (message or "CFG SAUVEGARDE") or "CFG ERREUR LUA"
  saveDetail=tostring(ok and (detail or message or "Echec SD") or result)
  -- Conserver la cause au lieu de la remplacer par un message generique.
  saveDetail=string.gsub(saveDetail,"^.-:%d+: ","")
  return false
 end
 saveError=nil;saveDetail=nil;return true
end
local function init()
 local ok,err=pcall(function()
  settings=loadModule("settings")
  core=loadModule("core")(settings);ui=loadModule("ui")(settings)
  audio=loadModule("audio");logger=loadModule("logger")
  local info=model.getInfo();local name=info.name or "MODELE"
  initStage="REGLAGES"
  c,store=settings.open(name);s=core.new(c);s.modelName=name
  voice=audio.new();log=logger.new()
  if LCD_W~=128 or LCD_H~=64 then error("Ecran 128x64 requis") end
 end)
 if not ok then fatal=initStage..": "..tostring(err) end
end
local function tick()
 if fatal or not s then return end
 local ticks=getTime()
 -- Une acquisition par instant, meme si plusieurs evenements arrivent.
 if lastTick==ticks then return end
 lastTick=ticks
 core.update(s,c,ticks/100)
 if s.openMenu then
  s.openMenu=false
  if not menu then menu={draft=settings.copy(c),index=1,editing=false} end
 end
 s.error=saveError or log.error or store.warning or s.audioError
 core.screen(s,c,menu~=nil)
 audio.update(voice,s,c)
 local ok=pcall(logger.update,log,s,c)
 if not ok then log.error="ERREUR JOURNAL";log.failed=true;log.active=false end
 -- Un outil peut etre ferme de force par le firmware sans appel final.
 -- Sauvegarder le vol actif toutes les 15 s limite alors la perte de compteurs.
 if s.active and s.now>=nextCheckpoint then
  core.checkpoint(s,c);nextCheckpoint=s.now+15
 end
 if s.dirty then save(c);s.dirty=false end
 s.error=saveError or log.error or store.warning or s.audioError
 if menu then menu.audioError=s.audioError end
end
local function equal(event,key) return key~=nil and event==key end
local function action(event)
 -- Molette de la Boxer et alias virtuels EdgeTX.
 if equal(event,EVT_ROT_RIGHT) or equal(event,EVT_PLUS_FIRST) or equal(event,EVT_PLUS_REPT) or
    equal(event,EVT_VIRTUAL_NEXT) or equal(event,EVT_VIRTUAL_INC) then return 1 end
 if equal(event,EVT_ROT_LEFT) or equal(event,EVT_MINUS_FIRST) or equal(event,EVT_MINUS_REPT) or
    equal(event,EVT_VIRTUAL_PREV) or equal(event,EVT_VIRTUAL_DEC) then return -1 end
 if equal(event,EVT_ENTER_BREAK) or equal(event,EVT_ROT_BREAK) or equal(event,EVT_VIRTUAL_ENTER) then return "enter" end
 if equal(event,EVT_EXIT_BREAK) or equal(event,EVT_VIRTUAL_EXIT) then return "exit" end
end
local function menuEvent(event)
 if not menu or s.screen~="settings" then return end
 -- ENT long sur la ligne Son : test explicite des fichiers, au sol.
 if settings.menuFields[menu.index] and settings.menuFields[menu.index].key=="audio" and
   (equal(event,EVT_ENTER_LONG) or equal(event,EVT_ROT_LONG) or equal(event,EVT_VIRTUAL_ENTER_LONG)) then
  local ok,message=audio.test(voice,c,s.armed,s.finder)
  menu.message=message;menu.ignoreEnterUntil=s.now+1
  if type(killEvents)=="function" then killEvents(event) end
  return
 end
 local a=action(event)
 if a=="enter" and menu.ignoreEnterUntil then
  local ignore=s.now<=menu.ignoreEnterUntil;menu.ignoreEnterUntil=nil
  if ignore then return end
 end
 if a=="exit" then
  -- RTN termine d'abord l'edition, puis quitte sans appliquer le brouillon.
  if menu.editing then menu.editing=false else menu=nil end
 elseif a=="enter" then
  if menu.index==#settings.menuFields+1 then
   -- Les statistiques sont conservees, seuls les champs du menu sont copies.
   local candidate=settings.copy(c)
   for _,f in ipairs(settings.fields) do candidate[f.key]=menu.draft[f.key] end
   candidate.sensorName=settings.sensorName(menu.draft)
   if save(candidate) then c=candidate;menu=nil
   else menu.message=saveError;menu.detail=saveDetail end
  else menu.editing=not menu.editing;menu.message=nil end
 elseif type(a)=="number" then
  menu.detail=nil;menu.message=nil
  if menu.editing then
   settings.adjust(settings.menuFields[menu.index],menu.draft,a)
  else menu.index=(menu.index-1+a)%(#settings.menuFields+1)+1 end
 end
end
local function run(event)
 if not s and not fatal then init() end
 if fatal then
  if action(event)=="exit" then return 1 end
  lcd.clear();lcd.drawText(0,0,"JWAIO BOXER",0)
  lcd.drawText(0,16,string.find(fatal,"memory",1,true) and "MEMOIRE LUA INSUFFISANTE" or "INSTALLATION A VERIFIER",SMLSIZE)
  -- Appels explicites string.* : aucune metatable de chaine requise.
  -- Afficher plusieurs lignes pour ne pas masquer la cause initiale.
  local message=string.gsub(fatal,BASE,"")
  message=string.sub(message,-75)
  lcd.drawText(0,30,string.sub(message,1,25),SMLSIZE)
  lcd.drawText(0,40,string.sub(message,26,50),SMLSIZE)
  lcd.drawText(0,50,string.sub(message,51,75),SMLSIZE)
  return 0
 end
 tick()
 if not menu and action(event)=="exit" then
  -- Sortie normale : memoriser aussi un vol encore actif et sa derniere ligne.
  -- Ce n'est pas une commande de desarmement du quad.
  if s.active then core.checkpoint(s,c) end
  if save(c) then
   s.active=false
   pcall(logger.update,log,s,c)
   return 1
  end
  -- Echec de sauvegarde : rester ouvert et afficher l'erreur pour reessayer.
  s.error=saveError
 end
 menuEvent(event);core.screen(s,c,menu~=nil);ui.draw(s,c,menu)
 return 0 -- 0 maintient l'outil ouvert ; 1 rend la main au menu TOOLS.
end
-- Les outils Lua n'ont pas de callback background persistant.
return {init=init,run=run}

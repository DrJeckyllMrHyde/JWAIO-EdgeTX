-- JWAIO Boxer V0.2.1 Alpha TOOLS - Copyright 2026 DrJeckyllMrHyde
-- SPDX-License-Identifier: Apache-2.0
-- Dessin natif 128 x 64. Les grandes valeurs utilisent une petite police
-- numerique 5 x 7 dessinee en blocs de 2 pixels : deux colonnes tiennent
-- exactement, sans dependre de la largeur DBLSIZE du firmware.
return function(settings)
 local M={}
 -- BEGIN WELCOME PIXEL ART
 -- 128 x 30, lignes encodees en x/largeur ; genere par tests/build_welcome.py.
 local welcomeRows={
  "",
  "",
  "\055\002",
  "\026\001\053\005",
  "\022\006\051\007\099\002\112\004",
  "\019\009\039\003\043\004\050\003\055\002\060\005\098\005\107\010",
  "\016\006\025\003\037\010\049\002\053\004\058\008\077\006\090\003\097\002\100\011\115\002",
  "\014\005\024\004\029\004\035\003\040\004\045\002\048\007\056\004\063\003\075\004\081\003\086\008\096\002\100\005\107\002\112\001\116\002",
  "\014\002\023\010\035\002\040\002\046\001\048\004\053\005\063\003\074\003\083\001\085\006\093\005\099\002\106\003\111\004\116\002",
  "\013\003\021\009\031\005\039\003\046\004\053\004\065\002\072\003\078\003\083\003\090\002\093\004\099\001\104\006\111\003\116\002",
  "\013\002\021\002\026\003\031\004\039\002\046\004\053\003\060\002\065\002\071\003\077\004\082\004\087\002\091\001\094\002\098\003\103\006\111\003\115\003",
  "\013\004\021\002\026\003\032\003\038\002\046\004\053\002\059\004\066\002\071\004\077\003\081\004\086\003\091\002\094\002\097\004\102\007\110\002\114\003",
  "\013\004\021\001\026\002\032\002\037\003\046\003\053\002\058\005\066\002\072\003\076\002\080\004\086\004\091\002\097\004\105\004\113\004",
  "\013\004\020\002\026\002\032\002\037\002\042\001\046\003\052\002\057\006\066\002\073\001\080\004\085\005\091\003\096\004\104\004\112\003",
  "\015\001\020\002\026\001\032\001\037\002\042\002\047\002\052\002\057\005\066\002\072\002\081\002\085\004\091\003\096\004\101\007\113\002",
  "\014\002\020\002\025\002\036\002\041\002\047\002\052\001\056\003\060\002\065\002\071\002\076\004\082\001\084\005\090\003\097\003\101\007\109\003\114\002",
  "\014\002\020\002\035\003\047\002\051\002\056\002\059\002\065\002\072\001\075\006\084\004\090\002\094\002\097\002\101\003\106\002\109\004\115\002",
  "\014\002\020\002\028\001\035\002\047\001\051\002\056\005\064\002\071\002\075\005\082\001\084\003\089\003\093\003\098\001\104\003\109\005\116\002",
  "\013\002\019\003\027\002\034\002\042\001\047\001\051\002\056\004\064\002\071\002\074\005\081\002\088\003\092\005\099\001\101\006\108\003\112\003\117\002",
  "\013\002\019\003\027\002\034\002\040\004\051\002\063\004\071\001\074\003\080\004\086\004\092\006\099\008\108\002\113\007",
  "\009\002\013\002\019\003\026\003\033\002\039\005\050\003\062\004\070\002\074\001\078\003\082\008\091\003\096\007\105\005\115\005",
  "\007\004\012\002\018\004\026\004\033\002\038\003\042\002\046\002\049\005\061\003\070\002\076\004\083\003\087\006\097\004\105\004\116\004",
  "\007\002\010\003\018\004\025\005\031\004\036\003\042\014\057\006\069\003\073\005\087\005\098\001\106\002\119\001",
  "\006\002\010\002\017\010\028\011\043\008\053\008\069\007\087\004",
  "\006\002\017\002\020\006\028\008\043\001\055\004\070\004\088\001",
  "\006\002\015\004\020\002\024\001",
  "\006\002\014\004",
  "\007\009",
  "\007\008",
  "\009\002",
 }
 -- END WELCOME PIXEL ART
 local function welcome()
  -- Paires d'octets x/largeur par ligne : pas de bitmap externe a charger,
  -- ni de boucle sur chaque pixel, ni de methode implicite des chaines.
  for y,row in ipairs(welcomeRows) do
   for i=1,#row,2 do
    lcd.drawFilledRectangle(string.byte(row,i),y-1,string.byte(row,i+1),1)
   end
  end
 end
 -- Police 5x7 : un octet par ligne (bits 4..0), plutot que 13 tables
 -- contenant chacune sept chaines. Le dessin reste pixel pour pixel identique.
 local digits={
  ["0"]="\014\017\019\021\025\017\014",
  ["1"]="\004\012\004\004\004\004\014",
  ["2"]="\014\017\001\002\004\008\031",
  ["3"]="\030\001\001\014\001\001\030",
  ["4"]="\002\006\010\018\031\002\002",
  ["5"]="\031\016\016\030\001\001\030",
  ["6"]="\014\016\016\030\017\017\014",
  ["7"]="\031\001\002\004\008\008\008",
  ["8"]="\014\017\017\014\017\017\014",
  ["9"]="\014\017\017\015\001\001\014",
  ["."]="\000\000\000\000\000\004\004",
  [":"]="\000\004\004\000\004\004\000",
  ["-"]="\000\000\000\031\000\000\000"
 }
 function M.time(seconds)
  local t=math.max(0,math.floor(seconds or 0))
  if t>=6000 then return "99:59" end -- largeur maximale du grand chrono
  return string.format("%02d:%02d",math.floor(t/60),t%60)
 end
 local function total(seconds)
  local t=math.floor(seconds or 0)
  if t>=3600 then return string.sub(string.format("%dH%02d",math.floor(t/3600),math.floor(t/60)%60),1,7) end
  return M.time(t)
 end
 local function text(x,y,str,flags) lcd.drawText(x,y,str,flags or SMLSIZE) end
 local function line(y) lcd.drawLine(0,y,127,y,SOLID,0) end
 local function header(left,right)
  lcd.drawFilledRectangle(0,0,128,9)
  text(1,1,left,SMLSIZE+INVERS)
  if right then text(128-#right*5-1,1,right,SMLSIZE+INVERS) end
 end
 local function big(x,y,str,scale)
  scale=scale or 2
  for i=1,#str do
   local rows=digits[string.sub(str,i,i)] or digits["-"]
   for r=1,7 do
    local row=string.byte(rows,r)
    -- Regrouper les pixels contigus reduit le nombre d'appels LCD.
    local start=nil
    for col=1,6 do
     if col<=5 and (row & (16 >> (col-1)))~=0 then start=start or col
     elseif start then
      lcd.drawFilledRectangle(x+(start-1)*scale,y+(r-1)*scale,(col-start)*scale,scale);start=nil
     end
    end
   end
   x=x+6*scale
  end
 end
 local function value(v,format,missing) return v and string.format(format,v) or (missing or "---") end
 local function footer(s)
  line(52)
  if s.error then text(1,56,string.sub(s.error,1,25))
  elseif s.finder or s.blackbox or s.failsafe then
   text(1,56,(s.blackbox and "BB " or "")..(s.failsafe and "FS " or "")..
    (s.beeper and "BEEP " or "")..(s.flip and "FLIP " or "")..(s.rth and "RTH " or ""))
  else text(1,56,"G"..value(s.throttle,"%d").."%")
   text(37,56,value(s.rssi,"%dDB"));text(84,56,"T"..total(s.totalSeconds))
  end
 end
 local function settingsPage(menu)
  local count=#settings.menuFields+1
  header("REGLAGES",string.format("%02d/%02d",menu.index,count))
  if menu.detail then
   text(1,12,"ECHEC SAUVEGARDE")
   text(1,22,string.sub(menu.message or "ERREUR SD",1,25))
   text(1,32,string.sub(menu.detail,1,25))
   text(1,42,string.sub(menu.detail,26,50))
   line(52);text(1,56,"ENT:REESSAYER RTN:ANNULER")
   return
  end
  local first=math.floor((menu.index-1)/4)*4+1
  for row=0,3 do
   local index=first+row;local f=settings.menuFields[index]
   local flags=SMLSIZE+(index==menu.index and INVERS or 0)
   local y=12+row*10
   if f then
    text(1,y,(index==menu.index and ">" or " ")..f.label,flags)
    text(83,y,string.sub(settings.format(f,menu.draft),1,9),flags)
   elseif index==count then text(1,y,"SAUVER + QUITTER",flags) end
  end
  line(52)
  text(1,56,menu.audioError or menu.message or (menu.editing and "MOLETTE: MODIFIER" or
   (settings.menuFields[menu.index] and settings.menuFields[menu.index].key=="audio" and "ENT LONG: TEST AUDIO" or "ENT:EDIT  RTN:ANNULER")))
 end
 -- Mesurer avec la police native : sizeText est reserve aux ecrans couleur.
 -- Le dessin de mesure est efface avant le rendu final du meme framebuffer.
 local widths={}
 local function measure(str,flags)
  local key=tostring(flags)..str
  if not widths[key] then
   lcd.drawText(0,0,str,flags)
   local getter=lcd.getLastPos or lcd.getLastRightPos
   widths[key]=getter and getter() or #str*(flags==MIDSIZE and 8 or (flags==SMLSIZE and 5 or 6))
  end
  return math.max(0,math.floor((128-widths[key])/2))
 end
 function M.draw(s,c,menu)
  local titleX,plugX,messageX
  local message=string.sub(s.error or "SF 5S : REGLAGES",1,25)
  if s.screen=="home" then
   titleX=measure("BIENVENUE",MIDSIZE)
   plugX=measure("BRANCHER LA LIPO",0);messageX=measure(message,SMLSIZE)
  end
  lcd.clear()
  if s.screen=="settings" then settingsPage(menu);return end
  if s.screen=="home" then
   welcome()
   text(titleX,34,"BIENVENUE",MIDSIZE)
   text(plugX,48,"BRANCHER LA LIPO",0)
   text(messageX,58,message)
  elseif s.screen=="ready" then
   header("AVANT VOL",c.cells.."S")
   text(1,13,s.error and "JWAIO !" or "JWAIO OK",SMLSIZE+(s.error and INVERS or 0))
   local sensor=string.upper(string.sub(settings.sensorName(c),1,5))
   text(78,13,sensor..(s.available and " OK" or " --"),SMLSIZE+(s.available and 0 or INVERS))
   line(23)
   lcd.drawRectangle(3,29,25,14);lcd.drawFilledRectangle(28,33,3,6)
   if s.cell then
    local floorV=c.profile==2 and 2.8 or 3.3
    local topV=c.profile==3 and 4.35 or 4.2
    local fill=math.floor(math.max(0,math.min(1,(s.cell-floorV)/(topV-floorV)))*21)
    if fill>0 then lcd.drawFilledRectangle(5,31,fill,10) end
   else text(12,33,"?",0) end
   big(38,29,value(s.cell,"%.2f","-.--"));text(102,35,"V/C")
   line(48)
   if s.lq~=nil then
    text(1,54,"ELRS "..math.floor(s.lq).."%"..(s.lq<=70 and " !" or ""))
    for i=1,8 do
     if s.lq>=i*12.5 then lcd.drawFilledRectangle(78+(i-1)*6,54,4,7)
     else lcd.drawRectangle(78+(i-1)*6,54,4,7) end
    end
   else text(1,54,"ELRS ABSENT",SMLSIZE+INVERS);text(85,54,"------") end
  elseif s.screen=="flight" then
   header("JWAIO",s.mode)
   if s.armed then text(49,1,"[ARM]",SMLSIZE+INVERS) end
   text(1,13,(s.cellMeasured and "MIN/C " or "V/CEL ")..c.cells.."S");text(69,13,"VOL")
   big(1,23,value(s.cell,"%.2f","-.--"));big(67,23,M.time(s.active and s.elapsed or 0))
   text(1,42,value(s.pack,"%.1fV"));text(69,42,"LQ "..value(s.lq,"%d").."%")
   footer(s)
  elseif s.screen=="finder" then
   header("QWAD FINDER",s.finderSource or "---")
   if s.finderValue then
    big(1,14,tostring(s.finderValue));text(83,22,s.finderSource=="RSSI" and "DBM" or "%")
   else text(1,19,"SIGNAL INDISPONIBLE") end
   lcd.drawRectangle(1,32,126,11)
   local w=math.floor(122*s.finderStrength/100)
   if w>0 then lcd.drawFilledRectangle(3,34,w,7) end
   text(1,46,"SIGNAL "..math.floor(s.finderStrength+0.5).."%")
   text(1,56,string.sub(s.error or (s.critical and "BAT CRITIQUE" or "FORCE DU SIGNAL / BIPS"),1,25))
  elseif s.screen=="critical" then
   header("! BAT CRITIQUE !",c.cells.."S")
   big(1,15,value(s.cell,"%.2f","-.--"),3);text(78,29,"V/CEL")
   text(1,43,"PACK "..value(s.pack,"%.1fV"));line(52)
   text(1,56,(s.armed and "[ARM] " or "")..s.mode.." VOL "..M.time(s.elapsed))
  elseif s.screen=="lost" then
   header("TELEM. ABSENTE","!")
   text(1,13,"PERTE APRES VOL")
   text(1,24,"DUREE "..M.time(s.active and s.elapsed or c.lastSeconds))
   text(1,35,"MIN BAT "..(c.lastCellCv>=0 and string.format("%.2fV",c.lastCellCv/100) or "---"))
   text(1,45,"DERNIERES MESURES")
   text(1,56,"VERIFIER LE QUAD")
  elseif s.screen=="summary" then
   header("BILAN DE VOL",nil)
   text(1,14,"DUREE");big(61,12,M.time(c.lastSeconds))
   text(1,32,"MIN BAT "..(c.lastCellCv>=0 and string.format("%.2f V/C",c.lastCellCv/100) or "---"))
   text(1,42,"MIN LQ "..(c.lastLq>=0 and c.lastLq.."%" or "---"))
   line(52);text(1,56,s.error or (not s.available and "CAPTEUR BAT ABSENT" or "TOTAL "..total(c.totalSeconds)))
  end
 end
 return M
end

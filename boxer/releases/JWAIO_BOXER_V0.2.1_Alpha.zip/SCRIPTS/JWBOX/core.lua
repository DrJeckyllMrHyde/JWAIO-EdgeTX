-- JWAIO Boxer V0.2.1 Alpha TOOLS - Copyright 2026 DrJeckyllMrHyde
-- SPDX-License-Identifier: Apache-2.0
-- Acquisition et machine d'etats. Aucune fonction ici ne commande le quad.
-- Les interrupteurs representent des COMMANDES de la radio,
-- jamais une confirmation d'armement ou de mode envoyee par Betaflight.
return function(settings)
 local M={}
 local function clamp(v,a,b) return math.max(a,math.min(b,v)) end
 local function finite(v) return type(v)=="number" and v==v and v~=math.huge and v~=-math.huge end
 local function source(name,telemetry)
  local field=getFieldInfo(name)
  if not field then return nil end
  if telemetry then
   -- EdgeTX 2.12 : current indique une mesure encore valide. fresh indique
   -- seulement l'arrivee recente d'un paquet et peut etre faux entre paquets.
   local ok,v,current=pcall(getSourceValue,field.id)
   if ok and current==true then return v end
   return nil -- ne pas reutiliser une ancienne valeur via getValue.
  end
  return getValue(field.id)
 end
 local function number(name,telemetry)
  local v=source(name,telemetry); if finite(v) then return v end
 end
 local function position(v)
  if v < -341 then return 1 elseif v > 341 then return 3 else return 2 end
 end
 local function switch(sw,pos)
  if sw==0 then return false end
  local v=number(string.lower(settings.switches[sw+1]))
  if v==nil then return false end
  local p=position(v); return pos==4 and p>=2 or p==pos
 end
 function M.new(c)
  return {elapsed=0,active=false,crash=false,critical=false,dirty=false,summaryQualified=false,
   totalBase=c.totalSeconds,screen="home",finderStrength=0,modelName=""}
 end
 local function snapshot(s,c)
  -- Le total est recalcule depuis la base du vol : une perte radio suivie
  -- d'une recuperation ne doit pas compter deux fois les memes secondes.
  c.totalSeconds=s.totalBase+math.floor(s.elapsed)
  c.lastSeconds=math.floor(s.elapsed);c.lastQualified=s.elapsed>10 and 1 or 0
  s.summaryQualified=s.elapsed>10
  c.lastCellCv=s.minCell and math.floor(s.minCell*100+0.5) or -1
  c.lastLq=s.minLq and math.floor(s.minLq) or -1
  c.lastRssi=s.minRssi and math.floor(s.minRssi) or -999
  c.lastThrottle=s.maxThrottle or 0
  s.dirty=true
 end
 function M.checkpoint(s,c)
  -- Point de reprise SD et sortie normale de l'outil. Ne commande pas ARM.
  if s.active then snapshot(s,c) end
 end
 function M.update(s,c,now)
  local dt=s.lastTime and math.max(0,now-s.lastTime) or 0
  -- Ne pas inventer du temps de vol dans un trou d'execution > 2 s.
  if dt>2 then dt=0 end
  s.lastTime=now;s.now=now
  s.armed=switch(c.armSw,c.armPos)
  s.prearmed=switch(c.prearmSw,c.prearmPos)
  s.beeper=switch(c.beeperSw,c.beeperPos);s.flip=switch(c.flipSw,c.flipPos)
  s.rth=switch(c.rthSw,c.rthPos);s.blackbox=switch(c.blackboxSw,c.blackboxPos)
  s.failsafe=switch(c.failsafeSw,c.failsafePos)
  s.finder=s.beeper or s.flip or s.rth
  s.mode=switch(c.angleSw,c.anglePos) and "ANGLE" or "ACRO"
  s.sf=switch(6,3)
  local throttle=number("ch"..c.throttleCh)
  s.throttle=throttle and math.floor(clamp((throttle+1024)*100/2048,0,100)+0.5) or nil
  -- getRSSI() surveille le flux global ; chaque capteur est aussi valide
  -- individuellement par getSourceValue. Stable ne signifie pas perime.
  local link=getRSSI();s.link=finite(link) and link>0
  s.pack=nil;s.cell=nil;s.cellMeasured=false;s.packZero=false
  if s.link then
   local raw=source(settings.sensorName(c),true)
   s.packZero=finite(raw) and raw==0
   if type(raw)=="table" then
    -- Cels fournit de vraies tensions individuelles : retenir la plus basse.
    local sum,min,count=0,nil,0
    for _,v in ipairs(raw) do
     if not finite(v) or v<0.5 or v>5.2 then count=0;break end
     count=count+1;sum=sum+v;min=math.min(min or v,v)
    end
    if count>=1 and count<=8 then s.pack=sum;s.cell=min;s.cellMeasured=true end
   elseif finite(raw) and raw>=0.5*c.cells and raw<=5.2*c.cells then
    -- RxBt/VFAS/Bat sont configures en tension PACK. Diviser par le nombre
    -- de cellules donne une MOYENNE, pas la cellule individuelle la plus faible.
    s.pack=raw;s.cell=raw/c.cells
   end
  end
  s.available=s.link and s.cell~=nil
  local lq=s.link and number("RQly",true) or nil
  s.lq=lq and lq>=0 and lq<=100 and lq or nil
  local rssi=s.link and number("1RSS",true) or nil
  s.rssi=rssi and rssi>=-140 and rssi<0 and rssi or nil
  -- Une mesure batterie absente n'est pas une preuve de debranchement.
  -- Avec la liaison encore presente, conserver le diagnostic en direct.
  if s.link then s.noLinkSince=nil
  else s.noLinkSince=s.noLinkSince or now end
  local disconnected=s.packZero or (not s.link and now-s.noLinkSince>=1)
  if s.link and not s.packZero then s.connected=true end
  if disconnected and not s.crash then
   if s.connected then s.homeEpoch=(s.homeEpoch or 0)+1 end
   s.connected=false;s.summaryQualified=false
  end
  -- Chaque nouvel armement avec une batterie valide lance un nouveau chrono,
  -- meme gaz a zero et meme si la LiPo du vol precedent est restee branchee.
  if not s.active and s.armed and s.available then
   s.active=true;s.elapsed=0;s.totalBase=c.totalSeconds;s.crash=false;s.summaryQualified=false
   s.minCell=nil;s.minLq=nil;s.minRssi=nil;s.maxThrottle=0;s.flightStart=now
  elseif s.active and s.armed and s.link and s.previousLink then
   s.elapsed=math.floor((s.elapsed+dt)*100+0.5)/100
  end
  if s.active and s.available then
   s.minCell=math.min(s.minCell or s.cell,s.cell)
   if s.lq then s.minLq=math.min(s.minLq or s.lq,s.lq) end
   if s.rssi then s.minRssi=math.min(s.minRssi or s.rssi,s.rssi) end
   s.maxThrottle=math.max(s.maxThrottle or 0,s.throttle or 0)
  end
  -- Une perte avec ARM encore actif apres >= 10 s est une suspicion de crash,
  -- pas une detection physique. Debrancher apres desarmement donne l'accueil.
  if s.active and s.armed and not s.link and s.elapsed>=10 and not s.crash then
   s.crash=true;snapshot(s,c)
  end
  if s.active and (not s.armed or s.packZero) then snapshot(s,c);s.active=false end
  if s.packZero then s.summaryQualified=false end
  if s.link and not s.packZero then s.crash=false end
  s.previousAvailable=s.available;s.previousLink=s.link
  -- L'ecran critique apparait des le passage STRICTEMENT sous le seuil.
  -- La sortie exige +0,08 V pendant 2 s pour eviter le clignotement en charge.
  if s.available and s.cell<c.criticalCv/100 then
   s.critical=true;s.recoverAt=nil
  elseif s.critical and s.available and s.cell>=c.criticalCv/100+0.08 then
   s.recoverAt=s.recoverAt or now
   if now-s.recoverAt>=2 then s.critical=false;s.recoverAt=nil end
  elseif not s.available then s.critical=false;s.recoverAt=nil
  else s.recoverAt=nil end
  -- Maintien SF de 5 s, declenchement unique jusqu'au relachement.
  -- Le suivi du vol continue meme lorsque le menu est affiche.
  if s.sf then
   s.sfAt=s.sfAt or now
   if now-s.sfAt>=5 and not s.sfConsumed then s.openMenu=true;s.sfConsumed=true end
  else s.sfAt=nil;s.sfConsumed=false end
  -- Le filtre Finder ne melange pas des dBm et un pourcentage de LQ.
  local raw,kind
  if s.finder and s.link then
   if s.rssi then raw=s.rssi;kind="RSSI" elseif s.lq then raw=s.lq;kind="LQ" end
  end
  if raw then
   if kind~=s.finderSource or not s.finderFiltered then s.finderFiltered=raw end
   local alpha=1-math.exp(-dt/0.1)
   s.finderFiltered=s.finderFiltered+(raw-s.finderFiltered)*alpha;s.finderSource=kind
   s.finderStrength=kind=="LQ" and clamp(s.finderFiltered,0,100) or clamp((s.finderFiltered+110)*100/70,0,100)
   s.finderValue=math.floor(s.finderFiltered+0.5)
   s.finderPeriod=0.2+1.0*(1-s.finderStrength/100)^2
  else s.finderFiltered=nil;s.finderValue=nil;s.finderPeriod=nil;s.finderStrength=0 end
  s.totalSeconds=s.active and s.totalBase+math.floor(s.elapsed) or c.totalSeconds
  M.screen(s,c,false)
 end
 function M.screen(s,c,menu)
  -- SF est une demande manuelle prioritaire. Hors menu : perte qualifiee,
  -- critique, accueil, Finder, vol, bilan, avant-vol. Les compteurs continuent.
  if menu then s.screen="settings"
  elseif not s.link and s.crash then s.screen="lost"
  elseif s.critical and (s.armed or not s.summaryQualified) then s.screen="critical"
  elseif not s.connected then s.screen="home"
  elseif s.finder then s.screen="finder"
  elseif s.armed then s.screen="flight"
  elseif s.summaryQualified then s.screen="summary"
  else s.screen="ready" end
  return s.screen
 end
 return M
end

-- JWAIO Boxer V0.2.1 Alpha TOOLS - Copyright 2026 DrJeckyllMrHyde
-- SPDX-License-Identifier: Apache-2.0
-- Reglages persistants : format texte strict, sans executer de code de la SD.
-- Deux copies alternees permettent de relire la precedente si une ecriture
-- est interrompue. Une sauvegarde n'est annoncee reussie qu'apres relecture.
local M = {}
M.switches = {"OFF", "SA", "SB", "SC", "SD", "SE", "SF"}
M.positions = {"HAUT", "MILIEU", "BAS", "MIL+BAS"}
M.sensors = {"RxBt", "VFAS", "Cels", "Bat"}
M.profiles = {"LiPo", "LiIon", "LiHv"}
-- Les bornes protegent aussi contre un fichier modifie ou endommage.
-- Position 4 = milieu OU bas ; OFF desactive une commande optionnelle.
M.fields = {
 {key="cells", label="Cellules", min=1, max=8, default=6},
 {key="profile", label="Batterie", min=1, max=3, default=1, choices=M.profiles},
 {key="sensor", label="Capteur BAT", min=1, max=4, default=1, choices=M.sensors},
 {key="criticalCv", label="Critique V/C", min=280, max=435, default=350},
 {key="armSw", label="ARM switch", min=1, max=6, default=1},
 {key="armPos", label="ARM pos.", min=1, max=3, default=3, choices=M.positions},
 {key="finderSw", label="Finder sw.", min=0, max=6, default=3},
 {key="finderPos", label="Finder pos.", min=1, max=4, default=4, choices=M.positions},
 {key="prearmSw", label="Prearm sw.", min=0, max=6, default=0},
 {key="prearmPos", label="Prearm pos.", min=1, max=3, default=3, choices=M.positions},
 {key="beeperSw", label="Beeper sw.", min=0, max=6, default=0},
 {key="beeperPos", label="Beeper pos.", min=1, max=4, default=3, choices=M.positions},
 {key="flipSw", label="Flip sw.", min=0, max=6, default=0},
 {key="flipPos", label="Flip pos.", min=1, max=4, default=3, choices=M.positions},
 {key="angleSw", label="ANGLE sw.", min=0, max=6, default=0},
 {key="anglePos", label="ANGLE pos.", min=1, max=3, default=3, choices=M.positions},
 {key="throttleCh", label="Voie gaz", min=1, max=4, default=3},
 {key="audio", label="Sons", min=0, max=1, default=1, choices={[0]="OFF",[1]="ON"}},
 {key="logs", label="Journal SD", min=0, max=1, default=1, choices={[0]="OFF",[1]="ON"}}
}
-- Les champs Finder historiques restent lisibles mais ne commandent plus rien.
-- Les nouveaux champs facultatifs sont OFF par defaut.
for _,name in ipairs({"blackbox","failsafe","rth"}) do
 M.fields[#M.fields+1]={key=name.."Sw",label=name,min=0,max=6,default=0}
 M.fields[#M.fields+1]={key=name.."Pos",label=name.." pos",min=1,max=3,default=3}
end
-- Lire les capteurs du modele sans changer l'ordre des quatre anciens choix.
if model and model.getSensor then
 for i=0,63 do
  local ok,sensor=pcall(model.getSensor,i)
  if ok and sensor and type(sensor.name)=="string" and #sensor.name>0 then
   local found=false
   for _,name in ipairs(M.sensors) do if name==sensor.name then found=true end end
   if not found then M.sensors[#M.sensors+1]=sensor.name end
  end
 end
end
M.fields[3].max=#M.sensors
M.menuFields={}
local order={"cells","profile","sensor","criticalCv","prearmSw","armSw","angleSw",
 "blackboxSw","beeperSw","flipSw","failsafeSw","rthSw","throttleCh","audio","logs"}
local labels={prearmSw="Prearm",armSw="Arm",angleSw="Angle",blackboxSw="BlackBox",
 beeperSw="Beeper",flipSw="Flip",failsafeSw="Failsafe",rthSw="RTH",audio="Son"}
-- Une seule instance de chaque paire switch/position, partagee par les
-- listes du menu. Eviter 95 petites tables identiques sur la Boxer.
local threePositions={[2]=true,[3]=true}
local armChoices,prearmChoices,commandChoices={},{},{ {sw=0,pos=3} }
prearmChoices[1]=commandChoices[1]
for sw=1,6 do
 for pos=1,3 do
  if pos~=2 or threePositions[sw] then
   local choice={sw=sw,pos=pos}
   armChoices[#armChoices+1]=choice
   prearmChoices[#prearmChoices+1]=choice
   if sw<=4 then commandChoices[#commandChoices+1]=choice end
  end
 end
end
for _,key in ipairs(order) do
 for _,f in ipairs(M.fields) do
  if f.key==key then
   f.label=labels[key] or f.label
   if string.match(key,"Sw$") then
    f.positionKey=string.gsub(key,"Sw$","Pos")
    f.switchChoices=key=="armSw" and armChoices or
     (key=="prearmSw" and prearmChoices or commandChoices)
   end
   M.menuFields[#M.menuFields+1]=f
  end
 end
end
function M.sensorName(c) return c.sensorName or M.sensors[c.sensor] or "RxBt" end
local stats = {"totalSeconds", "lastSeconds", "lastQualified", "lastCellCv", "lastLq", "lastRssi", "lastThrottle"}
function M.defaults()
 local c = {}; for _,f in ipairs(M.fields) do c[f.key]=f.default end
 c.totalSeconds=0; c.lastSeconds=0; c.lastQualified=0; c.lastCellCv=-1; c.lastLq=-1
 c.lastRssi=-999; c.lastThrottle=0; return c
end
function M.copy(c) local t={}; for k,v in pairs(c) do t[k]=v end; return t end
function M.format(f,c)
 local v=c[f.key]
 if f.key=="sensor" then return M.sensorName(c) end
 if string.match(f.key,"Sw$") then
  if v==0 then return "OFF" end
  -- CHAR_UP/DOWN sont les caracteres natifs EdgeTX, pas de l'UTF-8.
  local up=CHAR_UP or "^";local down=CHAR_DOWN or "v"
  local suffix=({up,"-",down,"-"..down})[c[f.positionKey or string.gsub(f.key,"Sw$","Pos")]]
  if f.switchChoices then
   local valid=false
   for _,choice in ipairs(f.switchChoices) do
    if choice.sw==v and choice.pos==c[f.positionKey] then valid=true;break end
   end
   if not valid then suffix=(suffix or "").."?" end
  end
  return M.switches[v+1]..(suffix or "?")
 end
 if f.key=="criticalCv" then return string.format("%.2f",v/100) end
 if f.key=="throttleCh" then return "CH"..v end
 return f.choices and f.choices[v] or tostring(v)
end
function M.adjust(f,c,direction)
 if f.switchChoices then
  local index=nil
  for i,choice in ipairs(f.switchChoices) do
   if c[f.key]==choice.sw and (choice.sw==0 or c[f.positionKey]==choice.pos) then index=i;break end
  end
  -- Une affectation heritee impossible (ex. SA milieu) est signalee a
  -- l'affichage mais n'est corrigee que lors d'une modification explicite.
  index=index and math.max(1,math.min(#f.switchChoices,index+direction)) or 1
  local choice=f.switchChoices[index];c[f.key]=choice.sw;c[f.positionKey]=choice.pos
 else
  c[f.key]=math.max(f.min,math.min(f.max,c[f.key]+direction))
  if f.key=="sensor" then c.sensorName=M.sensors[c.sensor] end
 end
end
local function hash(s)
 local h=0; for i=1,#s do h=(h*33+string.byte(s,i))%2147483647 end; return h
end
local function read(path)
 local f=io.open(path,"r"); if not f then return nil end
 -- Petits blocs : eviter un tampon temporaire de 4 Ko sur la Boxer.
 -- Toujours fermer le fichier, y compris si une lecture leve une erreur.
 local s=""
 for i=1,33 do
  local ok,part=pcall(io.read,f,128)
  if not ok or type(part)~="string" then
   io.close(f);return nil,"CFG LECTURE",tostring(part)
  end
  if #s+#part>4096 then io.close(f);return nil,"CFG TROP LONG" end
  s=s..part
  if #part<128 then io.close(f);return s end
 end
 io.close(f);return nil,"CFG TROP LONG"
end
local function join(lines)
 -- Ne pas dependre de la bibliotheque table sur une radio monochrome.
 local result="";for i,line in ipairs(lines) do result=result..line.."\n" end;return result
end
local function hex(s)
 -- EdgeTX peut suspendre Lua a chaque tranche de temps. Un rappel Lua
 -- execute par string.gsub interdit cette suspension (frontiere C).
 -- Garder ces conversions dans des boucles Lua ordinaires, suspendables.
 local result=""
 for i=1,#s do result=result..string.format("%02X",string.byte(s,i)) end
 return result
end
local function unhex(s)
 if not s or #s>64 or #s%2~=0 or string.find(s,"[^%x]") then return nil end
 local result=""
 for i=1,#s,2 do
  result=result..string.char(tonumber(string.sub(s,i,i+1),16))
 end
 return result
end
local function encode(owner,c,revision)
 local lines={"JWBOX=2","owner="..owner,"revision="..revision}
 for _,f in ipairs(M.fields) do lines[#lines+1]=f.key.."="..c[f.key] end
 for _,k in ipairs(stats) do lines[#lines+1]=k.."="..math.floor(c[k]) end
 lines[#lines+1]="sensorName="..hex(M.sensorName(c))
 local body=join(lines)
 return body.."checksum="..hash(body).."\n"
end
local function decode(s,owner)
 if not s then return nil end
 local body,sum=string.match(s,"^(.-)checksum=(%d+)\n$")
 if not body or hash(body)~=tonumber(sum) then return nil end
 local t={}; for k,v in string.gmatch(body,"([%w]+)=([^\n]+)\n") do
  if t[k] then return nil end; t[k]=v
 end
 if (t.JWBOX~="1" and t.JWBOX~="2") or t.owner~=owner then return nil end
 local revision=tonumber(t.revision)
 if not revision or revision<1 or revision%1~=0 or revision>1000000000 then return nil end
 local c=M.defaults()
 for _,f in ipairs(M.fields) do
  local v=tonumber(t[f.key])
  local min,max=f.min,f.max
  if f.key=="sensor" and t.JWBOX=="2" then max=68 end
  if t.JWBOX=="1" then
   if f.key=="criticalCv" then min,max=250,420 end
   if f.key=="throttleCh" then max=16 end
   if f.key=="sensor" then max=4 end
   if f.key=="blackboxSw" or f.key=="blackboxPos" or f.key=="failsafeSw" or
      f.key=="failsafePos" or f.key=="rthSw" or f.key=="rthPos" then v=f.default end
  end
  if not v or v%1~=0 or v<min or v>max then return nil end
  c[f.key]=v
 end
 for _,k in ipairs(stats) do
  local v=tonumber(t[k]); if not v or v%1~=0 or v < -999 or v > 1000000000 then return nil end
  c[k]=v
 end
 if c.totalSeconds<0 or c.lastSeconds<0 or (c.lastQualified~=0 and c.lastQualified~=1) or c.lastCellCv < -1 or c.lastCellCv>520 or
    c.lastLq < -1 or c.lastLq>100 or c.lastRssi>0 or c.lastThrottle<0 or c.lastThrottle>100 then return nil end
 if t.JWBOX=="2" then
  c.sensorName=unhex(t.sensorName)
  if not c.sensorName or #c.sensorName==0 then return nil end
  for i,name in ipairs(M.sensors) do if name==c.sensorName then c.sensor=i end end
 end
 if c.criticalCv<280 then c.criticalCv=280;c.migrated=true end
 if c.throttleCh>4 then c.throttleCh=3;c.migrated=true end
 return c,revision
end
function M.open(modelName)
 local owner=hex(string.sub(modelName or "MODEL",1,80))
 local base=string.format("/SCRIPTS/JWBOX/CFG/M%07d",hash(owner)%10000000)
 local a,ae=read(base..".a");local b,be=read(base..".b")
 local ca,ra=decode(a,owner); local cb,rb=decode(b,owner)
 local slot=(rb or 0)>(ra or 0) and "b" or "a"
 local c=slot=="a" and ca or cb
 -- Si les deux copies sont invalides, les valeurs par defaut sont visibles.
 -- Une collision de nom de fichier ne doit jamais ecraser un autre modele.
 local function foreign(data)
  if not data then return false end
  local body,sum=string.match(data,"^(.-)checksum=(%d+)\n$")
  return body and hash(body)==tonumber(sum) and string.match(body,"owner=([^\n]+)")~=owner
 end
 local collision=foreign(a) or foreign(b)
 return c or M.defaults(), {owner=owner,base=base,slot=c and slot or "b",
  revision=math.max(ra or 0,rb or 0),collision=collision,
  warning=(not c and (ae or be)) or ((not c and (a or b)) and "CFG INVALIDE") or
   (c and c.migrated and "CFG A VERIFIER" or nil)}
end
function M.save(store,c)
 if store.collision then return false,"CFG COLLISION" end
 local slot=store.slot=="a" and "b" or "a"
 local revision=store.revision+1; local data=encode(store.owner,c,revision)
 local path=store.base.."."..slot
 local f,reason=io.open(path,"w")
 if not f and type(mkdir)=="function" then
  -- EdgeTX 2.12 : mkdir retourne 0 (cree) ou 8 (deja present).
  -- Le dossier peut avoir ete omis pendant la copie des seuls fichiers Lua.
  local ok,status=pcall(mkdir,"/SCRIPTS/JWBOX/CFG")
  if not ok or (status~=0 and status~=8) then
   return false,"CFG DOSSIER",tostring(status)
  end
  f,reason=io.open(path,"w")
 end
 if not f then return false,"CFG OUVERTURE",tostring(reason or path) end
 -- io.write EdgeTX n'a pas les methodes fichier: f:write() est interdit.
 for i=1,#data,128 do
  local ok,written,err=pcall(io.write,f,string.sub(data,i,i+127))
  if not ok or written==false or (written==nil and err~=nil) then
   io.close(f);return false,"CFG ECRITURE",tostring(ok and err or written)
  end
 end
 io.close(f)
 local reread,readError,detail=read(path)
 if readError then return false,readError,detail end
 if reread~=data then return false,"CFG VERIFICATION","Fichier incomplet ou different" end
 local verified,rev=decode(reread,store.owner)
 if not verified or rev~=revision then return false,"CFG ECRITURE" end
 store.slot=slot;store.revision=revision;store.warning=nil;return true
end
return M

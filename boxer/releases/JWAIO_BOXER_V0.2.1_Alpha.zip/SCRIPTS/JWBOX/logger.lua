-- JWAIO Boxer V0.2.1 Alpha TOOLS - Copyright 2026 DrJeckyllMrHyde
-- SPDX-License-Identifier: Apache-2.0
-- Journal sans GPS : une ligne par seconde, avec champs vides si absents.
-- Un fichier par vol ; ouverture/fermeture a chaque ecriture pour la SD.
local M={}
local function join(values)
 local result="";for i,v in ipairs(values) do result=result..(i>1 and "," or "")..v end;return result
end
local function exists(path)
 local f=io.open(path,"r");if not f then return false end;io.close(f);return true
end
local function append(path,line,mode)
 local f=io.open(path,mode or "a")
 if not f and type(mkdir)=="function" then
  -- Reparer uniquement les dossiers du journal, jamais les fichiers existants.
  for _,dir in ipairs({"/LOGS","/LOGS/JWBOX"}) do
   local ok,status=pcall(mkdir,dir)
   if not ok or (status~=0 and status~=8) then return false end
  end
  f=io.open(path,mode or "a")
 end
 if not f then return false end
 for i=1,#line,128 do
  local ok,written,err=pcall(io.write,f,string.sub(line,i,i+127))
  if not ok or written==false or (written==nil and err~=nil) then
   io.close(f);return false
  end
 end
 io.close(f);return true
end
function M.new() return {active=false,nextWrite=0} end
local function filename()
 local dt=getDateTime()
 local base=string.format("/LOGS/JWBOX/F%02d%02d%02d_%02d%02d%02d",
  (dt.year or 2000)%100,dt.mon or 1,dt.day or 1,dt.hour or 0,dt.min or 0,dt.sec or 0)
 for i=0,99 do
  local path=base..(i>0 and "_"..i or "")..".csv"
  if not exists(path) then return path end
 end
end
function M.update(log,s,c)
 if s.active and not log.active and not log.failed and c.logs==1 then
  log.path=filename()
  if not log.path or not append(log.path,"radio_s,flight_s,armed,telemetry,pack_v,cell_v,lq,rssi_dbm,throttle_pct,finder,blackbox,failsafe,rth,model\n","w") then
   log.error="LOG OUVERTURE";log.failed=true;return
  end
  log.active=true;log.nextWrite=s.now;log.error=nil
 end
 if log.active and (s.now>=log.nextWrite or not s.active) then
  local function num(v,precision) return v and string.format("%."..precision.."f",v) or "" end
  local line=join({num(s.now,2),num(s.elapsed,2),s.armed and "1" or "0",s.link and "1" or "0",
   num(s.pack,2),num(s.cell,3),num(s.lq,0),num(s.rssi,0),num(s.throttle,0),s.finder and "1" or "0",
   s.blackbox and "1" or "0",s.failsafe and "1" or "0",s.rth and "1" or "0",
   -- Le nom de modele ne peut pas injecter des colonnes CSV.
   (string.gsub(s.modelName or "","[,\r\n]","_"))}).."\n"
  if not append(log.path,line) then log.error="LOG ECRITURE";log.failed=true;log.active=false end
  log.nextWrite=s.now+1
 end
 if not s.active then log.active=false;log.failed=false end
end
return M

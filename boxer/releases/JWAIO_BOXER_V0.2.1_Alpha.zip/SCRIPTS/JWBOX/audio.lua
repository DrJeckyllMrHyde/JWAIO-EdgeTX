-- JWAIO Boxer V0.2.1 Alpha TOOLS - Copyright 2026 DrJeckyllMrHyde
-- SPDX-License-Identifier: Apache-2.0
-- WAV JWAIO et Failsafe JWWING. Toute annonce en attente est revalidee : une valeur
-- revenue normale pendant un autre son ne doit pas produire une fausse alerte.
local M={}
local files={welcome={"Accueil",2.376},critical={"batcrt",1.92},low={"batlow",1.27},link={"elrs",1.74},
 arm={"arm",0.83},prearm={"pre_arm",0.63},ACRO={"Acro",0.68},ANGLE={"angle",0.68},
 beeper={"beeper",1.005},flip={"flip",0.842},failsafe={"failsafe",2.232},rth={"RTH",0.738},
 finder={"finder_bip",0.142},full={"LipLii_full",0.85},fullHv={"Lihv_Full",0.87},throttle={"thr",0.34}}
M.assets=files
local confirmations={"beeper","flip","failsafe","rth"}
local finderOrder={"failsafe","beeper","flip","rth"}
local normalOrder={"critical","failsafe","link","prearm","arm","welcome","beeper","flip","rth",
 "throttle","low","full","fullHv","ANGLE","ACRO"}
function M.new()
 return {busyUntil=0,lastBeep=nil,pending={},episodes={},linkPlayed=false,fullPlayed=false,present={},testIndex=nil}
end
local function episode(a,key,active,now,hold)
 local e=a.episodes[key]
 if not active then
  a.pending[key]=nil
  if e and key=="low" then
   e.offSince=e.offSince or now;e.since=now
   if now-e.offSince>=5 then a.episodes[key]=nil end
  else a.episodes[key]=nil end
  return
 end
 if not e then e={since=now,played=false};a.episodes[key]=e end
 e.offSince=nil
 if not e.played and now-e.since>=hold then a.pending[key]=true end
end
local function fullBattery(a,s,c)
 -- Une annonce par session batterie ; le coeur signale les retours accueil.
 -- Un capteur manquant ne rearme pas cette annonce.
 if a.fullProfile~=c.profile then
  a.fullProfile=c.profile;a.fullPlayed=false;a.fullSince=nil
 end
 a.pending.full=nil;a.pending.fullHv=nil
 if a.batteryEpoch~=s.homeEpoch then
  a.batteryEpoch=s.homeEpoch;a.fullPlayed=false
 end
 if not s.available then a.fullSince=nil;return end
 local target=c.profile==3 and 4.35 or 4.20
 -- Petite tolerance d'arrondi uniquement pour les bornes des flottants.
 local inRange=math.abs(s.cell-target)<=0.20001
 if s.screen=="ready" and not s.armed and inRange and not a.fullPlayed then
  a.fullSince=a.fullSince or s.now
  if s.now-a.fullSince>=3 then a.pending[c.profile==3 and "fullHv" or "full"]=true end
 else a.fullSince=nil end
end
local BASE="/SOUNDS/fr/JWBOX/"
local testOrder={"welcome","prearm","arm","beeper","flip","failsafe","rth"}
-- Ne jamais interpreter l'absence de retour de playFile comme un echec :
-- EdgeTX ne fournit pas de confirmation de lecture sur le haut-parleur.
local function present(a,kind)
 local name=files[kind][1]..".wav"
 if a.present[kind]==nil then
  -- Aucun io.open/io.close de WAV dans Lua : laisser le lecteur EdgeTX
  -- gerer son fichier. Controler uniquement les metadonnees avant une demande.
  if type(fstat)=="function" then
   local ok,info=pcall(fstat,BASE..name)
   a.present[kind]=ok and type(info)=="table"
  else a.present[kind]=true end -- ancienne API : ne pas ouvrir un WAV en repli.
 end
 if not a.present[kind] then
  a.error=a.error or ("SON ABSENT "..name);return false
 end
 return true
end
local function submit(a,kind,now)
 if not present(a,kind) then return false end
 local ok=pcall(playFile,BASE..files[kind][1]..".wav")
 if not ok then
  a.playError="SON ERREUR "..files[kind][1];a.failedKind=kind
  a.error=a.playError;a.busyUntil=now+1;return false
 end
 if a.failedKind==kind then a.playError=nil;a.failedKind=nil end
 a.lastSubmitted=kind
 a.busyUntil=now+files[kind][2]+(kind=="finder" and 0.06 or 0.12)
 return true
end
function M.test(a,c,armed,finder)
 if armed then return false,"DESARMER POUR TEST" end
 if finder then return false,"COUPER BEEPER FLIP RTH" end
 if c.audio~=1 then return false,"ACTIVER ET SAUVER SON ON" end
 -- Recontroler les fichiers si l'utilisateur a recopie les sons sur la SD.
 a.present={};a.error=nil;a.playError=nil;a.failedKind=nil;a.testIndex=1
 return true,"TEST: ECOUTER 7 ANNONCES"
end
-- Fonction unique, plutot qu'une nouvelle fermeture allouee a chaque image.
local function report(a,s)
 s.audioError=a.error;s.audioTest=a.testIndex~=nil
end
function M.update(a,s,c)
 local now=s.now
 if a.startedAt==nil then
  a.startedAt=now;a.startupPending=c.audio==1;a.homeEpoch=s.homeEpoch or 0
 end
 local epoch=s.homeEpoch or 0
 if a.homeEpoch~=epoch then
  a.homeEpoch=epoch;a.pending.welcome=s.screen=="home" or nil
 end
 -- L'intro initiale reste demandee meme avec LiPo/ARM/Finder deja actifs.
 -- Les retours accueil, eux, sont annules si leur ecran n'est plus pertinent.
 if s.screen~="home" then a.pending.welcome=nil end
 local warn=c.profile==2 and 3.0 or 3.6
 warn=math.max(warn,c.criticalCv/100+0.10)
 episode(a,"critical",s.critical,now,1)
 episode(a,"low",s.available and s.cell<warn and not s.critical,now,1.2)
 episode(a,"throttle",s.armed and s.throttle and s.throttle>95,now,3)
 -- LQ <=70 : un episode, rearme uniquement par une mesure valide >70.
 if s.lq~=nil and s.lq>70 then a.linkPlayed=false end
 a.pending.link=s.armed and s.lq~=nil and s.lq<=70 and not a.linkPlayed or nil
 fullBattery(a,s,c)
 if not s.armed then a.armPlayed=false end
 a.pending.arm=s.armed and not a.armPlayed or nil
 -- Un prearm momentane ne doit pas disparaitre pendant l'intro/une annonce.
 if s.prearmed and not a.wasPrearmed then
  a.prearmPlayed=false;a.prearmUntil=now+6
 end
 a.wasPrearmed=s.prearmed
 local prearmRelevant=s.prearmed or (a.prearmUntil and now<a.prearmUntil)
 if not prearmRelevant then a.prearmPlayed=false end
 a.pending.prearm=prearmRelevant and not a.prearmPlayed or nil
 for _,kind in ipairs(confirmations) do
  if not s[kind] then a[kind.."Played"]=false end
  a.pending[kind]=s[kind] and not a[kind.."Played"] or nil
 end
 a.pending.ACRO=nil;a.pending.ANGLE=nil
 if s.available and s.mode~=a.modeSpoken then a.pending[s.mode]=true end
 if c.audio==0 then
  a.pending={};a.lastBeep=nil;a.startupPending=false;a.testIndex=nil;a.prearmUntil=nil
  s.audioError=nil;s.audioTest=false;return
 end
 -- Ne pas auditer la SD en parallele du lecteur audio. Les metadonnees
 -- d'un son ne sont demandees que juste avant sa lecture, puis mises en cache.
 a.error=a.playError
 for kind,exists in pairs(a.present) do
  if not exists then
   a.error=a.error or ("SON ABSENT "..files[kind][1]..".wav");break
  end
 end
 if now<a.busyUntil then report(a,s);return end
 -- Laisser passer le premier affichage de TOOLS avant l'intro initiale.
 if a.startupPending then
  if now-a.startedAt<0.30 then report(a,s);return end
  submit(a,"welcome",now);a.startupPending=false
  report(a,s);return
 end
 -- Les tests sont controles au sol, jamais par une activation de commande.
 if a.testIndex then
  if s.armed or s.finder then a.testIndex=nil
  else
   local kind=testOrder[a.testIndex]
   if kind then
    submit(a,kind,now);a.testIndex=a.testIndex+1
    if a.testIndex>#testOrder then a.testIndex=nil end
    report(a,s);return
   end
  end
 end
 local order=s.finder and finderOrder or normalOrder
 for _,kind in ipairs(order) do
  if a.pending[kind] then
   if submit(a,kind,now) then
    a.pending[kind]=nil
    if a.episodes[kind] then a.episodes[kind].played=true end
    if kind=="link" then a.linkPlayed=true
    elseif kind=="ACRO" or kind=="ANGLE" then a.modeSpoken=kind
    elseif kind=="full" or kind=="fullHv" then a.fullPlayed=true
    elseif kind~="welcome" then a[kind.."Played"]=true end
   end
   -- Un fichier absent ne doit pas affamer les autres annonces ou les bips.
   if now<a.busyUntil then report(a,s);return end
  end
 end
 if s.finder then
  if s.finderValue and (not a.lastBeep or now-a.lastBeep>=s.finderPeriod) then
   if submit(a,"finder",now) then a.lastBeep=now end
  end
 else a.lastBeep=nil end
 report(a,s)
end
return M

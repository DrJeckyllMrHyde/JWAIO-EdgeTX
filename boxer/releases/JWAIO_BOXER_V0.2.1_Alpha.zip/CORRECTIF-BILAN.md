# Correctif bilan — JWAIO_BOXER_V0.2.1_Alpha

Correctif préparé le 1er novembre 2026 après cinq passes de relecture. Le numéro de version et les chemins d'installation restent identiques.

## Audio et allocations

- La fonction de compte rendu audio est désormais partagée au lieu d'être recréée à chaque rafraîchissement.
- Le script n'ouvre plus les fichiers WAV avec `io.open` pour vérifier leur présence.
- La présence d'un son demandé est contrôlée une seule fois avec `fstat`, puis le résultat reste en cache.
- Aucun audit des seize fichiers audio n'est lancé en arrière-plan.
- Le test Son permet de réinitialiser le cache après avoir recopié les fichiers sur la carte SD.

## Mémoire

La collecte mémoire complète forcée avant chaque sauvegarde a été supprimée. La gestion mémoire normale du firmware et de Lua continue de fonctionner. Les collectes prévues pendant le chargement initial des modules restent conservées.

## Sauvegardes et refus SD

- Les statistiques restent en mémoire lorsqu'une sauvegarde est refusée.
- Le script effectue jusqu'à trois tentatives automatiques au total.
- Chaque nouvelle tentative est espacée d'au moins cinq secondes.
- Après trois refus, l'erreur reste visible et les données restent en attente.
- Une sauvegarde explicite depuis le menu ou une sortie normale permet de retenter l'écriture.
- Une sauvegarde réussie supprime la demande en attente.

Une coupure d'alimentation peut toujours entraîner la perte des données qui n'ont pas encore pu être enregistrées.

## Éléments conservés

- Les six scripts Lua, les seize WAV et le format des sauvegardes CFG conservent les mêmes chemins.
- Les sauvegardes alternées et leur vérification après relecture restent actives.
- Le journal écrit sa dernière ligne au désarmement puis s'arrête normalement.
- Le fonctionnement reste accessible depuis **SYS → TOOLS → JWAIO Boxer**.

## Vérifications réalisées

- Compilation des six sources sous Lua 5.3.
- Contrôles des menus, écrans, sauvegardes et refus SD dans les environnements Lua standard et monochrome restreint.
- 1 201 rafraîchissements audio sans ouverture de WAV par Lua et sans contrôle SD pendant une lecture en cours.
- Deux simulations de bilan de quinze minutes, avec Journal SD OFF puis ON.
- Quinze minutes de refus CFG sans rafale d'écritures.
- Reprise automatique validée lorsque la carte redevient disponible avant la deuxième tentative.
- Reprise par sauvegarde explicite validée après trois refus.

## Installation

Copier les dossiers `SCRIPTS`, `SOUNDS` et `LOGS` du ZIP à la racine de la carte SD. Conserver le dossier `SCRIPTS/JWBOX/CFG`, sauvegarder la carte avant la copie et retirer uniquement l'ancien fichier `jwbox.luac` s'il existe.

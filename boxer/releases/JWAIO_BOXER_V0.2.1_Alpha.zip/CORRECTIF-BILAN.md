# Correctif bilan — JWAIO_BOXER_V0.2.1_Alpha

Préparé le 1er novembre 2026 après cinq passes de relecture. Candidat à tester sur radio, distinct de la livraison finale précédente. Aucun changement de numéro de version, aucun envoi GitHub.

## Incident de référence

Boxer édition DFR sous EdgeTX 2.12.2, sans USB, Journal SD ON. Après un vol, le script est resté plus de cinq minutes ; au retour, LiPo débranchée, la radio a été retrouvée figée sur Bilan de vol. On ne sait pas si le gel est survenu avant ou pendant le débranchement. Cet incident montre que l'USB n'explique pas tous les gels. Pas d'accès à cette radio pour reproduire le problème.

## Passe 1 — États et attente prolongée

Relecture de core.lua et ui.lua : pas de boucle infinie propre au bilan. Le snapshot au désarmement est unique dans le scénario normal. Vérification du bilan stable, du retour accueil, de l'intro unique après perte de liaison assimilée à un retrait de batterie, puis du réarmement et du nouveau vol. Aucune modification de ces deux modules, pour conserver les priorités et le rendu.

Test accéléré : deux scénarios de quinze minutes à 20 Hz sur le bilan, Journal OFF puis ON, suivis du débranchement et d'un réarmement. Aucun io.open/io.write sur le bilan stable après la sauvegarde de fin de vol, aucune collecte complète imposée par l'application pendant cette attente. Cela ne reproduit ni la SD ni l'ordonnanceur de la radio.

## Passe 2 — Mémoire et allocations

La fonction de compte rendu audio était créée à chaque rafraîchissement. Elle devient une fonction commune, sans fermeture temporaire par image. Le tableau d'ordre des sondes WAV est retiré avec l'audit de fond.

La collecte complète forcée avant chaque sauvegarde est supprimée. La gestion mémoire normale du firmware/Lua continue ; les collectes avant et après les cinq modules au démarrage restent conservées. On évite ainsi de forcer un balayage complet au désarmement ou au point de reprise. Cela ne garantit pas un budget mémoire précis sur Boxer : les mesures hôte 64 bits ne sont pas la RAM de la radio.

## Passe 3 — SD, journal et intégrité des sauvegardes

Le journal écrit déjà une dernière ligne puis s'arrête au désarmement. Son format et les sauvegardes alternées vérifiées ne changent pas.

Défaut confirmé et reproduit sur la version d'origine : dirty était effacé même après un refus de sauvegarde. Le correctif conserve l'état à sauvegarder jusqu'au succès. Il effectue au maximum trois tentatives automatiques au total, espacées d'au moins cinq secondes après un échec. Après trois refus, l'erreur reste visible et les données restent en mémoire ; une sauvegarde explicite depuis le menu ou une sortie normale retente l'écriture. Une coupure d'alimentation peut toujours perdre les données non enregistrées.

Tests : quinze minutes de refus CFG sans rafale d'écritures, récupération par sortie explicite après les trois refus, et récupération automatique lorsque la carte redevient disponible avant la seconde tentative. Une réussite supprime la demande en attente. Le banc comparatif reproduit l'absence de reprise sur l'ancienne version et valide la reprise sur le correctif.

Les écritures CFG et CSV restent synchrones. Un appel natif bloqué dans le firmware ou une carte défectueuse ne peut pas être interrompu par pcall ; ce correctif ne prétend pas résoudre cette classe de panne matérielle.

## Passe 4 — Audio et accès aux fichiers

Le script n'ouvre et ne ferme plus les WAV dans Lua pour vérifier leur présence. Il utilise fstat avant la première demande de chaque son, puis garde le résultat en cache. Cette API est vérifiée dans le code EdgeTX v2.12.2 : radio/src/lua/api_filesystem.cpp. Sans API fstat, le lecteur natif reçoit directement la demande et aucun io.open de secours n'est utilisé.

Pas d'audit de seize fichiers au démarrage ; pas de nouvelle sonde de métadonnées pendant la durée théorique du WAV précédent demandé par JWAIO. Cela ne contrôle pas les annonces externes du modèle et ne garantit pas la fin réelle d'une lecture dans la file native. Les contrôles d'absence concernent les sons demandés, pas tout l'inventaire en arrière-plan. Le test Son réinitialise le cache.

Test dédié : 1201 images, quatorze demandes audio, io.open/io.close interdits dans le module audio et fstat interdit pendant la durée théorique de la lecture précédente. Les seize WAV sont inchangés.

## Passe 5 — Erreurs, régressions et livraison

Les six sources sont compilées sous Lua 5.3. La suite précédente repasse en environnement normal et sous restrictions monochromes : menus, sauvegardes, refus SD, appels suspendables à la frontière Lua/C, rendu, priorités, Finder depuis le bilan, annonces et chargement. Les tests d'endurance et d'erreur décrits ci-dessus passent dans les deux environnements.

Les quatre autres Lua restent identiques à la livraison finale, de même que les WAV et le format CFG. Le ZIP séparé est contrôlé par CRC, chemins, doublons et SHA-256. Il ne contient ni tests, ni réglages personnels, ni journaux de vol, ni fichiers .luac.

Le fonctionnement reste TOOLS. L'absence dans DISPLAY est indépendante : ce menu sélectionne SCRIPTS/TELEMETRY. Cette adaptation n'est pas mélangée au correctif de stabilité.

## Portée et prochain essai radio

Un défaut de persistance est corrigé et les allocations/accès SD inutiles sont réduits. La cause précise du gel rapporté n'est pas identifiée ; aucun gel natif n'est déclaré corrigé sans nouvelle observation matérielle.

Installer les trois dossiers SCRIPTS, SOUNDS et LOGS du ZIP en conservant CFG. Sauvegarder la SD auparavant et retirer uniquement l'ancien jwbox.luac éventuel. Tester sans USB, sur table sans hélices : vol simulé par les commandes pendant plus de dix secondes, désarmement, contrôle régulier des touches pendant au moins dix minutes, puis débranchement et retour accueil. Refaire avec Journal OFF puis ON. Contrôler aussi les sons et la sauvegarde/relecture des réglages. Conserver l'archive précédente pour revenir en arrière.

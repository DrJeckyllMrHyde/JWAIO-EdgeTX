# JWAIO v0.3.1 Preview — TX16S Mk3

- Interface adaptée au **800×480**, en conservant l'organisation TX15 : fond couvrant toute la zone, logo et jauges proportionnés, polices natives.
- Sources résolues par nom sur la Mk3, dix options et fonctionnalités TX15 conservées. Chemins et 28 médias inchangés.
- Effets RGB optionnels limités aux **20 LED des anneaux**, sans toucher aux six LED de boutons ; désactivés par défaut.
- Corrections timer et confirmation vocale du Finder reprises du portage Mk1/Mk2. Identifiant de build et notices spécifiques Mk3.

**406 contrôles logiciels réussis** sous Lua 5.3 avec API simulées, dont les tests LED et les rendus 800×480 / zones réduites. L'audit et le détail des contrôles sont inclus dans le ZIP.

**Firmware à confirmer :** RadioMaster demande EdgeTX 3.0.0 minimum. Les API ont été vérifiées sur la révision officielle `96ab2745d1bc0025c5508ac8a3b862f34cf97c6e`, la dernière release stable retournée étant v2.12.4 au moment de l'examen. La compatibilité avec le build exact installé et le fonctionnement sur radio réelle restent à valider.

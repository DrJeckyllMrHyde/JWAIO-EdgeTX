-- ============================================================================
-- JWAIO - BLACK CARBON | TX15 Full Black Edition
-- Carbone forge, aluminium noir et accents argent froid.
-- ============================================================================
return {
  api = 1,
  id = "black_carbon",
  name = "CARBON",
  slot = 4,
  background = "background.png",
  logo = "logo.png",
  panelsBaked = false,
  palette = {
    black = {2, 3, 4},
    panel = {7, 9, 11},
    line = {120, 130, 140},
    white = {236, 240, 244},
    grey = {130, 140, 150},
    orange = {180, 195, 210},
    green = {80, 220, 170},
    red = {255, 58, 58},
    blue = {90, 180, 255}
  }
}

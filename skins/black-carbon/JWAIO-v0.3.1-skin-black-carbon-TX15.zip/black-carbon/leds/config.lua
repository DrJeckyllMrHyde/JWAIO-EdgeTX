-- BLACK CARBON - Reglages LED faciles.
-- Une couleur est {rouge, vert, bleu}, avec chaque valeur entre 0 et 255.
return {
  enabled=1,
  count=20,
  brightness=25,
  fps=10,
  colors={
    ready={225,235,245},     -- Blanc froid discret.
    prearm={135,155,175},    -- Argent bleute.
    armed={245,248,250},    -- Blanc pur : halo des manches en ACRO.
    angle={92,190,130},     -- Vert doux : halo des manches en ANGLE.
    critical={255,58,58},    -- Rouge reserve aux alertes.
    finder={255,135,30},    -- Orange : Beeper et Flip, visible sans etre rouge.
    lost={170,185,200},
    satellite={80,220,170}
  }
}

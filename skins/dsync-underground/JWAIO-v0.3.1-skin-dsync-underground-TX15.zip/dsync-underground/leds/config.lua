-- DSYNC UNDERGROUND - Reglages LED faciles.
return {
  enabled=1,
  count=20,
  brightness=30,
  fps=10,
  colors={
    ready={230,245,250},     -- Blanc froid : radio prete.
    prearm={0,190,225},      -- Cyan : pre-arm.
    armed={0,225,255},       -- Cyan electrique : halo ACRO.
    angle={230,245,250},     -- Blanc graffiti : halo ANGLE.
    critical={255,55,65},    -- Rouge : batterie et RTH.
    finder={0,225,255},      -- Cyan : Finder.
    lost={120,145,150},
    satellite={50,235,190}
  }
}

-- ============================================================================
-- JWAIO - DSYNC CREW | Freestyle Underground / Bando
-- Beton noir, carbone et cyan electrique. Les panneaux restent dessines par
-- JWAIO afin que la telemetrie conserve la priorite absolue.
-- ============================================================================
return {
  api = 1,
  id = "dsync_underground",
  name = "DSYNC",
  slot = 5,
  background = "background.png",
  logo = "logo.png",
  panelsBaked = false,
  palette = {
    black = {1, 4, 5},
    panel = {4, 10, 12},
    line = {0, 185, 215},
    white = {242, 248, 250},
    grey = {120, 145, 150},
    orange = {0, 210, 235},
    green = {50, 235, 190},
    red = {255, 55, 65},
    blue = {0, 205, 240}
  }
}
